# subwayMap
A jquery plugin to render data as a subway map visualization

![image](https://user-images.githubusercontent.com/1822081/50102208-c1804d00-0224-11e9-8a8c-c5f5a83939cc.png)

# Usage 

Read the [step-by-step guide](https://kalyani.com/blog/2010/10/08/subway-map-visualization-jquery-plugin/) on the author blog 
